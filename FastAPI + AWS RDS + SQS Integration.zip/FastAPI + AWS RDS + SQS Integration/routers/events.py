from fastapi import APIRouter, HTTPException
from ..schemas import EventCreate
from ..event_queue import enqueue_event

router = APIRouter(prefix="/events")

@router.post("/")
async def create_event(event: EventCreate):
    try:
        await enqueue_event(event)
        return {"status": "event enqueued"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 
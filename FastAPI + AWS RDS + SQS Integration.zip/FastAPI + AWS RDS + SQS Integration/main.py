from fastapi import FastAPI
from routers import events
from worker import process_events

app = FastAPI(title="Event Ingestion Service")
app.include_router(events.router)

@app.on_event("startup")
async def startup_event():
    # Start the background worker
    process_events()
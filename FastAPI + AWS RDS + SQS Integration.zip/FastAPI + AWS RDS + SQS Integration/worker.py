import asyncio
import json
from datetime import datetime
from datetime import datetime, UTC
from event_queue import dequeue_event  
from database import SessionLocal
from models import EventLog

async def process_messages():
    db = SessionLocal()

    while True:
        try:
            event = await dequeue_event()  # Pull one event from SQS
            
            if not event:
                await asyncio.sleep(5)
                continue

            # Create DB record
            event_log = EventLog(
                user_id=event.user_id,
                event_type=event.event_type,
                event_metadata=event.event_metadata,
                original_timestamp=event.timestamp,
                processed_at=datetime.now(UTC)
            )
            print(f"Received event: {event.dict()}")
            db.add(event_log)
            db.commit()
            
            print("Event saved to database")

        except Exception as e:
            print(f"Error processing message: {e}")
            db.rollback()

        await asyncio.sleep(1)

if __name__ == "__main__":
    asyncio.run(process_messages())

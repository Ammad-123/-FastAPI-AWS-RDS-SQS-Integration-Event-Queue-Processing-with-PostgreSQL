import boto3
import json
from typing import Optional
from schemas import EventCreate

sqs = boto3.client("sqs", region_name="ap-southeast-2")
QUEUE_URL = "https://sqs.ap-southeast-2.amazonaws.com/32677378/event-queue"

async def enqueue_event(event: EventCreate):
    sqs.send_message(
        QueueUrl=QUEUE_URL,
        MessageBody=event.json()
    )

async def dequeue_event() -> Optional[EventCreate]:
    response = sqs.receive_message(
        QueueUrl=QUEUE_URL,
        MaxNumberOfMessages=1,
        WaitTimeSeconds=5  # long polling
    )

    if "Messages" in response:
        message = response["Messages"][0]
        body = message["Body"]
        receipt_handle = message["ReceiptHandle"]
        await delete_message(receipt_handle)
        return EventCreate.parse_raw(body)
    return None

async def delete_message(receipt_handle: str):
    sqs.delete_message(
        QueueUrl=QUEUE_URL,
        ReceiptHandle=receipt_handle
    )

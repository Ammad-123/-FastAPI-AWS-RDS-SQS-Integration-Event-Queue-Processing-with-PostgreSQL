from datetime import datetime
from typing import Dict, Optional
from pydantic import BaseModel

class EventCreate(BaseModel):
    user_id: str
    event_type: str
    event_metadata: Dict 
    timestamp: datetime
from sqlalchemy import Column, Integer, String, DateTime, JSON
from database import Base

class EventLog(Base):
    __tablename__ = "event_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, index=True)
    event_type = Column(String)
    event_metadata = Column(JSON) 
    original_timestamp = Column(DateTime)
    processed_at = Column(DateTime)